<div class="js-cookie-consent cookie-consent">

    <div class="container">
      <div class="cookie-container">
        <span class="cookie-consent__message">
          <?php echo $setting->cookie_alert_text; ?>

        </span>

        <button class="js-cookie-consent-agree cookie-consent__agree">
            <?php echo e(__('Allow Cookies')); ?>

        </button>
      </div>
    </div>

</div>
<?php /**PATH /home/spangkpd/cms.spandanit.com/core/resources/views/vendor/cookieConsent/dialogContents.blade.php ENDPATH**/ ?>